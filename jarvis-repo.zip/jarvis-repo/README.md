# Jarvis

Ein persönlicher Assistent (Chat + Sprache), gehostet über GitHub Pages.
Automatisierung im Hintergrund läuft über GitHub Actions.

## Was das hier ist – und was nicht

- **Ist:** eine Web-Oberfläche mit Chat und Spracherkennung/-ausgabe, die für Antworten die kostenlose Google-Gemini-API (Modell `gemini-2.5-flash`) nutzt. Läuft komplett im Browser, gehostet als statische Seite auf GitHub Pages.
- **Ist nicht:** ein echter Dauer-Server. GitHub kann nicht permanent "zuhören" oder direkt mit Geräten in deinem Heimnetz sprechen. Für Smart-Home-Steuerung bräuchtest du zusätzlich etwas wie Home Assistant bei dir zuhause, das über einen Webhook angesprochen wird – das ist ein möglicher nächster Ausbauschritt, aber noch nicht Teil dieser Version.

## Einrichtung

### 1. Repository anlegen
1. Auf GitHub ein neues Repository erstellen, z.B. `jarvis`.
2. Alle Dateien aus diesem Ordner hochladen (per Weboberfläche "Add file → Upload files" oder per `git push`).

### 2. GitHub Pages aktivieren
1. Im Repo: **Settings → Pages**.
2. Bei "Source" den Branch `main` und Ordner `/ (root)` auswählen.
3. Speichern. Nach ein bis zwei Minuten ist die Seite unter `https://<dein-username>.github.io/<repo-name>/` erreichbar.

### 3. API-Key eintragen
1. Seite öffnen.
2. Beim ersten Aufruf erscheint ein Feld für den Google-Gemini-API-Key (siehe unten, falls noch keiner vorhanden).
3. Key einfügen und speichern. Er wird nur lokal im Browser gespeichert (`localStorage`), nicht im Repo.

### 4. Kostenlosen Gemini-API-Key erstellen
1. Auf [aistudio.google.com](https://aistudio.google.com) mit einem Google-Konto anmelden (keine Kreditkarte nötig).
2. Oben auf **"Get API key"** klicken.
3. **"Create API key"** wählen.
4. Key kopieren (beginnt mit `AIza...`).

**Kostenloses Kontingent (Stand 2026):** Modell `gemini-2.5-flash` mit rate-limitiertem Free Tier (u.a. begrenzte Anfragen pro Minute/Tag) – für einen persönlichen Assistenten normalerweise ausreichend. Bei "429 Too Many Requests" einfach kurz warten. Falls Google das Kontingent künftig ändert, in `index.html` einfach die Variable `MODEL` anpassen.

## Sprachsteuerung

Der Mikrofon-Button nutzt die Web Speech API des Browsers (funktioniert zuverlässig in Chrome/Edge). Antworten werden zusätzlich per Sprachausgabe vorgelesen.

## Automatisierung erweitern

`.github/workflows/daily-briefing.yml` zeigt, wie GitHub Actions zeitgesteuert Aufgaben erledigen kann – hier als Platzhalter, der täglich eine kleine JSON-Datei aktualisiert. Das lässt sich ausbauen, z.B.:
- Wetter- oder Kalenderdaten abrufen und in `data/briefing.json` schreiben.
- Die `index.html` so erweitern, dass sie `data/briefing.json` beim Start lädt und anzeigt.
- Weitere Workflows für andere wiederkehrende Aufgaben ergänzen.

## Nächste sinnvolle Ausbaustufen

- **Persönliches Gedächtnis:** Verlauf dauerhaft speichern (aktuell nur die letzten 20 Nachrichten pro Browser).
- **Tool-Nutzung:** Der KI erlauben, z.B. Kalender oder To-do-Listen abzufragen (braucht zusätzliche Anbindung).
- **Smart-Home-Bridge:** Verbindung zu Home Assistant via Webhook für echte Gerätesteuerung.
